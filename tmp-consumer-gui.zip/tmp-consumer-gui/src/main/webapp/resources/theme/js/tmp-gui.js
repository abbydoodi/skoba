function initialize() {
	hideErrorMsg();
}

function validate() {
	var url = document.getElementById("url").value;	
	var success = 1;

	// -------------------------//
	// -------------------------//
	// ------ url checking -----//
	// -------------------------//
	// -------------------------//
	if (url == "") {
		success = 0;
		document.getElementById("urlLbl").className = "labelred";
		showErrorMsg("Error: One or more required fields missing.");
	} else {
		document.getElementById("urlLbl").className = "label1";
	}
	
	if (success == 1) {
		document.getElementById("mainForm").submit();
	}	
}

function showErrorMsg(errMsg) {
	var errText = "<label class=\"labelred\">" + errMsg + "</label>";
	document.getElementById("errorMsg").innerHTML = errText;
	document.getElementById("errorMsg").visible = true;
}

function hideErrorMsg() {
	document.getElementById("errorMsg").visible = false;
}
