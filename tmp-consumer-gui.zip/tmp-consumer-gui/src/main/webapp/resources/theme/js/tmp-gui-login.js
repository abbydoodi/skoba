function initialize() {
	hideErrorMsg();
}

function validate() {
	var user = document.getElementById("user").value;	
	var password = document.getElementById("password").value;
	var success = 1;

	// -------------------------//
	// -------------------------//
	// ----- user checking -----//
	// -------------------------//
	// -------------------------//
	if (user == "") {
		success = 0;
		document.getElementById("userLbl").className = "labelred";
		showErrorMsg("Error: One or more required fields missing.");
	} else {
		document.getElementById("userLbl").className = "label1";
	}
	
	// -------------------------//
	// -------------------------//
	// --- password checking ---//
	// -------------------------//
	// -------------------------//
	if (password == "") {
		success = 0;
		document.getElementById("passwordLbl").className = "labelred";
		showErrorMsg("Error: One or more required fields missing.");
	} else {
		document.getElementById("passwordLbl").className = "label1";
	}

	if (success == 1) {
		document.getElementById("isinForm").submit();
	}	
}

function showErrorMsg(errMsg) {
	var errText = "<label class=\"labelred\">" + errMsg + "</label>";
	document.getElementById("errorMsg").innerHTML = errText;
	document.getElementById("errorMsg").visible = true;
}

function hideErrorMsg() {
	document.getElementById("errorMsg").visible = false;
}
