package com.commerzbank.tmp.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class RestService {
	
	private static final Logger LOG = LoggerFactory
			.getLogger(RestService.class);
	
	public String getResponse(String url){
		RestTemplate template = new RestTemplate();
		String response = null;
		try{
			response = template.getForObject(url, String.class);
		}catch(Exception e){
			response = "Error encountered: " + e.getLocalizedMessage();
		}
		LOG.info(response);
		return response;
	}
}
