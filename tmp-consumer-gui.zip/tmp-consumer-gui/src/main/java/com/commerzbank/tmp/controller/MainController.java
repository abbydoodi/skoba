package com.commerzbank.tmp.controller;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.commerzbank.tmp.service.RestService;
import com.commerzbank.tmp.service.UserService;

@Controller
public class MainController {

	private static final Logger LOG = LoggerFactory
			.getLogger(MainController.class);

	@Autowired
	RestService restService;

	@Autowired
	UserService userService;

	int loginSuccess = 0;

	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public ModelAndView showMainPage(Locale locale, Model model,
			@ModelAttribute("url") String url) {

		ModelAndView modelAndView = new ModelAndView();

		if (url != null) {
			String response = restService.getResponse(url);
			modelAndView.addObject("url", url);
			modelAndView.addObject("response", response);
		}

		if (loginSuccess == 1) {
			modelAndView.setViewName("main");
		} else {
			modelAndView.setViewName("login");
		}
		return modelAndView;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView doLogout(Locale locale, Model model) {
		loginSuccess = 0;
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("error", "");
		modelAndView.setViewName("login");
		return modelAndView;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView showLoginPage(Locale locale, Model model,
			@ModelAttribute("user") String user,
			@ModelAttribute("password") String password) {

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("error", "");
		modelAndView.setViewName("login");

		if ((user.length() > 0) && (password.length() > 0)) {
			if (userService.validateCredentials(user, password)) {
				loginSuccess = 1;
				LOG.info("Account Credentials valid.");
				modelAndView.setViewName("main");
			} else {
				modelAndView.addObject("error", "Error: Invalid user credentials.");
				LOG.info("Invalid user credentials.");
			}

		}
		return modelAndView;
	}

}