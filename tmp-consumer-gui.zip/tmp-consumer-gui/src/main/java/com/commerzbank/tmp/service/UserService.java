package com.commerzbank.tmp.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {

	public boolean validateCredentials(String user, String password){
		if((user.toUpperCase().equals("ADMIN")) && (password.toUpperCase().equals("PASSWORD"))){
			return true;
		}
		return false;
	}
	
}
